package util

// Cell is used as the return type for the testing framework.
type Cell struct {
	X, Y int
}